<?php

declare(strict_types=1);

/**
 * Front controller. The only PHP file inside the web root.
 *
 * Everything else — the application code, the brand packs, the database and the
 * API key — lives above it and is not servable.
 */

/*
 * Where the application lives, relative to this file.
 *
 * In the repository the docroot is public/ and the app is its sibling src/.
 * On the server the docroot is plan.swytch.graphics/ and the app is
 * coverapp/src/ beside it. Both are tried rather than either being assumed,
 * so the same index.php works in both places and a wrong guess says so
 * instead of producing a blank page.
 */
$coverBootstrap = null;
foreach ([
    dirname(__DIR__) . '/src/bootstrap.php',              // the repository
    dirname(__DIR__) . '/coverapp/src/bootstrap.php',     // the server
] as $candidate) {
    if (is_file($candidate)) {
        $coverBootstrap = $candidate;
        break;
    }
}

if ($coverBootstrap === null) {
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    echo "The application files are not where this page expects them.\n\n";
    echo "Looked for:\n";
    echo "  " . dirname(__DIR__) . "/src/bootstrap.php\n";
    echo "  " . dirname(__DIR__) . "/coverapp/src/bootstrap.php\n\n";
    echo "Upload coverapp.zip so that coverapp/src/ sits beside this document root.\n";
    exit;
}

require $coverBootstrap;

$app = cover_boot();
App::sendPrivacyHeaders();
$app->enforceHttps();

$auth = $app->auth();
$auth->start();

$path = App::path();
$method = App::method();

// ---- Open to anyone -------------------------------------------------------

if ($path === '/login') {
    if ($method === 'POST') {
        $password = is_string($_POST['password'] ?? null) ? $_POST['password'] : '';
        $result = $auth->signIn($password, App::clientIp());
        if ($result['ok']) {
            App::redirect('/');
        }
        $app->render('login', ['title' => 'Marketing cover', 'error' => $result['message']]);
    }

    if ($auth->isSignedIn()) {
        App::redirect('/');
    }
    $app->render('login', ['title' => 'Marketing cover', 'error' => null]);
}

// ---- Everything below needs the password ----------------------------------

if (!$auth->isSignedIn()) {
    if (str_starts_with($path, '/api/')) {
        App::jsonError('Your session has expired. Reload the page and enter the password again.', 401);
    }
    App::redirect('/login');
}

if ($path === '/logout' && $method === 'POST') {
    $auth->signOut();
    App::redirect('/login');
}

// §5: the day view is "the screen the app opens on".
if ($path === '/' && $method === 'GET') {
    require APP_ROOT . '/src/handlers/day.php';
    cover_day($app);
}

if ($path === '/closeout' && $method === 'POST') {
    require APP_ROOT . '/src/handlers/day.php';
    cover_closeout($app);
}

if ($path === '/assistant' && $method === 'GET') {
    $card = null;
    $cardMissing = false;
    $requested = $_GET['card'] ?? null;
    if (is_string($requested) && $requested !== '') {
        $card = ctype_digit($requested) ? $app->cards()->find((int) $requested) : null;
        $cardMissing = $card === null;
    }

    $app->render('assistant', [
        'title' => 'Assistant — Marketing cover',
        'card' => $card,
        'cardMissing' => $cardMissing,
    ]);
}

// ---- Cards (BRIEF.md §3 and §8) -------------------------------------------

if ($path === '/cards' && $method === 'GET') {
    $contextParam = is_string($_GET['context'] ?? null) ? $_GET['context'] : '';
    $activeContexts = [];
    foreach (array_filter(explode(',', $contextParam)) as $key) {
        if (Contexts::find($key) !== null) {
            $activeContexts[] = $key;
        }
    }
    $activeStatus = is_string($_GET['status'] ?? null) ? $_GET['status'] : '';
    if ($activeStatus !== 'open' && !in_array($activeStatus, Cards::STATUSES, true)) {
        $activeStatus = '';
    }
    $sort = ($_GET['sort'] ?? '') === 'title' ? 'title' : 'due';

    $app->render('cards', [
        'title' => 'All work — Marketing cover',
        'cards' => $app->cards()->all($activeContexts, $activeStatus, $sort),
        'activeContexts' => $activeContexts,
        'activeStatus' => $activeStatus,
        'sort' => $sort,
        'totalCards' => $app->cards()->countAll(),
    ]);
}

if ($path === '/cards/new' && $method === 'GET') {
    require APP_ROOT . '/src/handlers/cards.php';
    cover_card_new($app);
}

if ($path === '/cards' && $method === 'POST') {
    require APP_ROOT . '/src/handlers/cards.php';
    cover_card_save($app, null);
}

if (preg_match('#^/cards/(\d+)$#', $path, $m) === 1) {
    require APP_ROOT . '/src/handlers/cards.php';
    if ($method === 'POST') {
        cover_card_save($app, (int) $m[1]);
    }
    if ($method === 'GET') {
        cover_card_edit($app, (int) $m[1]);
    }
}

if (preg_match('#^/cards/(\d+)/status$#', $path, $m) === 1 && $method === 'POST') {
    require APP_ROOT . '/src/handlers/cards.php';
    cover_card_status($app, (int) $m[1]);
}

if ($path === '/api/cards.csv' && $method === 'GET') {
    require APP_ROOT . '/src/handlers/cards.php';
    cover_cards_csv($app);
}

if ($path === '/log' && $method === 'GET') {
    $app->render('log', [
        'title' => 'Log — Marketing cover',
        'entries' => $app->logBook()->all(),
    ]);
}

if ($path === '/health' && $method === 'GET') {
    require APP_ROOT . '/src/handlers/health.php';
    cover_health($app);
}

if ($path === '/api/log.csv' && $method === 'GET') {
    $csv = $app->logBook()->toCsv();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . Csv::filename('marketing-cover-log') . '"');
    header('Cache-Control: no-store');
    echo $csv;
    exit;
}

if ($path === '/api/assistant' && $method === 'POST') {
    require APP_ROOT . '/src/handlers/assistant.php';
    cover_assistant($app);
}

if ($path === '/api/note' && $method === 'POST') {
    require APP_ROOT . '/src/handlers/note.php';
    cover_note($app);
}

// ---- Nothing matched ------------------------------------------------------

http_response_code(404);
$app->render('notfound', ['title' => 'Not found — Marketing cover']);
